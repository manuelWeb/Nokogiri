require 'htmlbeautifier'
require 'slim'
Slim::Engine.set_options pretty: true

# SLIM to HTML
srcfile = File.open("indexC.slim", "rb").read
outFile = Slim::Template.new{srcfile}
out = File.open("indexC.html", "w")
out.puts outFile.render
out.close

# htmlbeautifier
dirty_file = File.read("indexC.html")
outclean = File.open("indexC.html", "w")
beautiful = HtmlBeautifier.beautify(dirty_file, tab_stops: 2)
outclean.puts beautiful
outclean.close 